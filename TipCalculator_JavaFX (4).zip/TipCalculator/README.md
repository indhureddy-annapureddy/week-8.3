# Tip Calculator (JavaFX + FXML)

## Files
- `src/main/resources/com/example/tipcalculator/tip_calculator.fxml` — UI layout
- `src/main/java/com/example/tipcalculator/TipCalculatorController.java` — input validation and calculations
- `src/main/java/com/example/tipcalculator/TipCalculatorApp.java` — JavaFX application entry point

## Run
Use a Java IDE with JavaFX configured (for example, IntelliJ IDEA), or create a JavaFX project and copy these files into the matching package/resource paths.

The app accepts non-negative numeric bill amounts and tip percentages. For example, bill `50` and percentage `15` produces `Tip Amount: $7.50`.
