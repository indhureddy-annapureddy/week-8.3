package com.example.tipcalculator;

import java.util.Locale;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class TipCalculatorController {
    @FXML
    private TextField billAmountField;

    @FXML
    private TextField tipPercentageField;

    @FXML
    private Label tipAmountLabel;

    @FXML
    private Label errorMessageLabel;

    @FXML
    private void calculateTip() {
        errorMessageLabel.setText("");

        try {
            String billText = billAmountField.getText().trim();
            String percentageText = tipPercentageField.getText().trim();

            double billAmount = Double.parseDouble(billText);
            double tipPercentage = Double.parseDouble(percentageText);

            if (!Double.isFinite(billAmount) || !Double.isFinite(tipPercentage)
                    || billAmount < 0 || tipPercentage < 0) {
                errorMessageLabel.setText(
                    "Error: Please enter valid non-negative numbers.");
                tipAmountLabel.setText("Tip Amount: $0.00");
                return;
            }

            double tipAmount = billAmount * tipPercentage / 100.0;
            tipAmountLabel.setText(
                String.format(Locale.US, "Tip Amount: $%.2f", tipAmount));
        } catch (NumberFormatException ex) {
            tipAmountLabel.setText("Tip Amount: $0.00");
            errorMessageLabel.setText(
                "Error: Invalid input. Please enter numbers.");
        }
    }

    @FXML
    private void reset() {
        billAmountField.clear();
        tipPercentageField.clear();
        tipAmountLabel.setText("Tip Amount: $0.00");
        errorMessageLabel.setText("");
    }
}
