package com.example.tipcalculator;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class TipCalculatorApp extends Application {
    @Override
    public void start(Stage stage) throws Exception {
        FXMLLoader loader = new FXMLLoader(
            TipCalculatorApp.class.getResource("tip_calculator.fxml"));
        Scene scene = new Scene(loader.load(), 360, 390);

        stage.setTitle("Tip Calculator");
        stage.setScene(scene);
        stage.setMinWidth(320);
        stage.setMinHeight(360);
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
